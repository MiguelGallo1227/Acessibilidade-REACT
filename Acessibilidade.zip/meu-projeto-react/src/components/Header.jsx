import React from "react";

function Header() {
  return (
    <header className="app-header">
      <h1>Meu Site</h1>
      <nav>
        <ul>
          <li>
            <a href="/">Home</a>
          </li>
          <li>
            <a href="/produtos">Produtos</a>
          </li>
          <li>
            <a href="/contato">Contato</a>
          </li>
        </ul>
      </nav>
    </header>
  );
}

export default Header;
