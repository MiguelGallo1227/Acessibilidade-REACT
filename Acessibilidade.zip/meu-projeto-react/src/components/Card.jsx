import React from "react";

// Usamos "props" (propriedades) para passar dados para este componente
function Card({ imageUrl, title, description }) {
  return (
    <div className="card">
      <img src={imageUrl} alt={description} />
      <h3>{title}</h3>
      <button>Ver Detalhes</button>
    </div>
  );
}

export default Card;
