import React from "react";
import Card from "./Card";

// 1. Importe suas imagens locais
import ImagemUm from "../assets/imagem1.jpg";
import ImagemDois from "../assets/imagem2.jpg";
import ImagemTres from "../assets/imagem3.jpg";

function Main() {
  const cardData = [
    {
      id: 1,
      title: "Card 1",
      // 2. Use as imagens importadas aqui
      imageUrl: ImagemUm,
      description: "Descrição da Imagem 1 para acessibilidade",
    },
    {
      id: 2,
      title: "Card 2",
      imageUrl: ImagemDois,
      description: "Descrição da Imagem 2 para acessibilidade",
    },
    {
      id: 3,
      title: "Card 3",
      imageUrl: ImagemTres,
      description: "Descrição da Imagem 3 para acessibilidade",
    },
  ];

  return (
    <main className="app-main">
      {/* ... (o restante do código continua igual) ... */}
      {cardData.map((card) => (
        <Card
          key={card.id}
          title={card.title}
          imageUrl={card.imageUrl}
          description={card.description}
        />
      ))}
    </main>
  );
}

export default Main;
